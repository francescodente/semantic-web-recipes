Jena README
===========

Welcome to Apache Jena, a Java framework for writing Semantic Web applications.

See http://jena.apache.org/ for the project website, including documentation.

The codebase for the active modules is in git:

https://github.com/apache/jena
